import inspect
import unittest
from dataclasses import FrozenInstanceError


from core.bridge import (
    ActionIntent,
    BridgeError,
    BridgeErrorCode,
    BridgeResult,
    LLMBridgeProvider,
)


class BridgeContractTests(unittest.TestCase):
    def setUp(self):
        self.intent = ActionIntent(
            action_type='MODIFY_FILE',
            target_path='src/main.py',
            content="print('Giorgio')\n",
            expected_sha256='0' * 64,
            reasoning_summary='Aggiorna il file principale.',
        )
        self.error = BridgeError(
            code=BridgeErrorCode.INVALID_INTENT,
            message='Payload non valido.',
            provider='test',
            exception_type='ValueError',
        )

    def test_bridge_result_requires_exactly_one_variant(self):
        with self.assertRaises(ValueError):
            BridgeResult()
        with self.assertRaises(ValueError):
            BridgeResult(intent=self.intent, error=self.error)

        success = BridgeResult(intent=self.intent)
        failure = BridgeResult(error=self.error)
        self.assertIs(success.intent, self.intent)
        self.assertIsNone(success.error)
        self.assertIs(failure.error, self.error)
        self.assertIsNone(failure.intent)

    def test_action_intent_and_result_are_frozen(self):
        result = BridgeResult(intent=self.intent)
        with self.assertRaises(FrozenInstanceError):
            self.intent.content = 'mutazione'
        with self.assertRaises(FrozenInstanceError):
            result.error = self.error
        with self.assertRaises(FrozenInstanceError):
            self.error.message = 'mutazione'

    def test_provider_interface_is_abstract(self):
        self.assertTrue(inspect.isabstract(LLMBridgeProvider))
        with self.assertRaises(TypeError):
            LLMBridgeProvider()

        class MissingRequestIntent(LLMBridgeProvider):
            @property
            def provider_name(self):
                return 'missing'

        with self.assertRaises(TypeError):
            MissingRequestIntent()


if __name__ == '__main__':
    unittest.main()
